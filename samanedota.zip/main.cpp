#include "Admin.h"

string split(string& inp){
    string splited;
    for(char c: inp){
        if(c==' '){
            continue;
        }
        else{
            splited+=c;
        }
    }
    return splited;
}

int main(){
    //admin default
    Admin admin1;
    while (true){
        cout<<"Please enter your username and password"<<endl;
        cout<<"username: ";
        string user;
        string pass;
        cin>>user;
        cout<<"password: ";
        cin>>pass;
        if(user=="Admin"){
            string admin_id;
            cout<<"Enter yor admin id"<<endl;
            cin>>admin_id;
            Admin new_admin(admin_id,user,pass);
        }
        else if(user=="Professor"){
            string professor_name;
            cout<<"Enter yor professor_name"<<endl;
            cin>>professor_name;
            string professor_number;
            cout<<"Enter yor professor_number"<<endl;
            cin>>professor_number;
            Professor professor1=admin1.create_professor(professor_name,professor_number,user,pass);
            string course_3="Riazi";
            string course_2="Fizik";
            string course_1="AP";
            Course course1(course_1);
            Course course2(course_2);
            Course course3(course_3);
            professor1.create_course(course1);
            professor1.create_course(course2);
            professor1.create_course(course3);
        }
        else if(user=="Student"){
            string student_number;
            cout<<"Enter yor student_number"<<endl;
            cin>>student_number;
            Student student1=admin1.create_student(student_number,user,pass);
        }
        else{
            cout<<"Wrong username!\n";
            continue;
        }
        string ending;
        cout<<"Do you wanna end the program? yes/no"<<endl;
        cin>>ending;
        if(ending=="yes" || ending=="Yes"){
            break;
        }
    }
}