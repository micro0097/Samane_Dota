#include "Person.h"

person::person(string& _username,string& _password) {
    this->username=_username;
    this->password=_password;
}
